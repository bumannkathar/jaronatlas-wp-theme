<article class="no-posts">
    <header class="page-header">
        <h1 class="page-title"><?php esc_html_e( 'Sorry, hier bsit du falsch', 'jaronatlastheme' ); ?></h1>
    </header>
    <div class="page-content">
        <p><?php esc_html_e( "Sieht so aus als hättest du dich verlaufen. Versuch es doch mal mit der Suche!", 'jaronatlastheme' ); ?></p>
        <?php get_search_form(); ?>
    </div>
</article>
