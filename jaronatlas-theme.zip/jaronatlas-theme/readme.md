# Projektzusammenfassung

  

Dieses einfache Theme basiert auf den Unterlagen des Repos [im4_wordpress_theme](https://github.com/Interaktive-Medien/im4_wordpress_theme). Aus diesem wurde z.B. die Struktur abgeleitet.

Das Theme enthält unter anderem folgende Features:
- Eine Customizable Navbar mit Logo und Description
- Dynamisches Haupt und Footer Menü
- Globales Bootstrap für ein möglichst responsives Design
- Customizable Social Media Links für den Footer

  

## Installation

1. Git Repo als ZIP herunterladen

2. In wordpress unter "Appearance" -> "Themes" -> "Add New" -> "Upload Theme" hochladen

3. Aktivieren